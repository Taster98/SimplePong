#!/bin/bash
./simple_pong
